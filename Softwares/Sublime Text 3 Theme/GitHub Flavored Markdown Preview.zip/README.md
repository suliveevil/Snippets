# GitHub Flavored Markdown preview plugin

## Overview

Sublime Text 2/3 plugin for [GitHub Flavored Markdown](http://github.github.com/github-flavored-markdown/).

## Installation

1. Install the Sublime Package Control package: <https://packagecontrol.io/installation>
2. Use Package Control to install this package (GitHubMarkdownPreview)

## Key bindings

`"ctrl+shift+g"`

## License

MIT
